/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Riko
 */
public class InfoLahan extends DataTanah{
    public List<String> jenisTanaman;

    public InfoLahan() {
        jenisTanaman = new ArrayList<>();
    }
    
    public InfoLahan(String jenisTanaman, String lokasi, Integer luasL, String jenisTanah, Integer hargaPerbulan, Integer hargaPertahun) {
        super(lokasi, luasL, jenisTanah, hargaPerbulan, hargaPertahun);
        this.jenisTanaman.add(jenisTanaman);
    }
    
    /* set dengan satu parameter untuk menambahkan arraylist, 2 parameter
       untuk menimpa arraylist dengan value yang baru
    */
    
    public String getJenisTanaman(int data) {
        return jenisTanaman.get(data);
        
    }

    public void setJenisTanaman(String tanaman) {
        jenisTanaman.add(tanaman);
    }
    
    public void setJenisTanaman(int data, String tanaman) {
        jenisTanaman.set(data, tanaman);
    }
    
    
}

