/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 * @Codeblocks
 * @author Bima Prakoso
 */
public class User {
    public List<Integer> id;
    public List<String> nama;
    private List<String> nomer;
    private List<String> gender;
    private List<String> alamat;
    public List<String> avatar;
    private List<String> email;
    public List<String> password;
    public List<String> pemilik;
    public List<String> pengelola;
	
    public User() {
	id = new ArrayList<>();
        nama = new ArrayList<>();
        nomer = new ArrayList<>();
        gender = new ArrayList<>();
        alamat = new ArrayList<>();
        avatar = new ArrayList<>();
        email = new ArrayList<>();
        password = new ArrayList<>();
        pemilik = new ArrayList<>();
        pengelola = new ArrayList<>();
    }
    
    public Integer getId(int data) {
	return id.get(data);
    }
	
    public void setId(Integer idUser) {
	id.add(idUser);
    }
	
    public String getNama(int no) {
	return nama.get(no);
    }
	
    public void setNama(String name) {
	nama.add(name);
    }
	
    public String getNomer(int no) {
	return nomer.get(no);
    }
	
    public void setNomer(String noHp) {
	nomer.add(noHp);
    }
    
    public void setNomer(int data, String noHp) {
	nomer.add(data, noHp);
    }
	
    public String getGender(int no) {
	return gender.get(no);
    }
	
    public void setGender(String jenKel) {
	gender.add(jenKel);
    }
    
    public void setGender(int data, String jenKel) {
	gender.add(data, jenKel);
    }
	
    public String getAlamat(int no) {
	return alamat.get(no);
    }
	
    public void setAlamat(String street) {
	alamat.add(street);
    }
    
    public void setAlamat(int data, String street) {
	alamat.add(data, street);
    }
    
    public String getAvatar(int no) {
	return avatar.get(no);
    }
	
    public void setAvatar(String foto) {
	avatar.add(foto);
    }
    
    public void setAvatar(int data, String foto) {
	avatar.add(data, foto);
    }
	
    public String getEmail(int no) {
	return email.get(no);
    }
	
    public void setEmail(String mail) {
	email.add(mail);
    }
    
    public void setEmail(int data, String mail) {
	email.add(data, mail);
    }
	
    public String getPassword(int no) {
	return password.get(no);
    }
	
    public void setPassword(String pass) {
	password.add(pass);
    }
    
    public void setPassword(int data, String pass) {
	password.add(data, pass);
    }
           
    public String getPemilik(int data) {
        return pemilik.get(data);
    }

    public void setPemilik(String pemilikA) {
        this.pemilik.add(pemilikA);
    }
    
    public void setPemilik(int data, String namaPemilik) {
        pemilik.set(data, namaPemilik);
    }

    public String getPengelola(int data) {
        return pengelola.get(data);
    }

    public void setPengelola(String pengelolaa) {
        this.pengelola.add(pengelolaa);
    }
    
    public void setPengelola(int data, String namaPengelola) {
        pengelola.set(data, namaPengelola);
    }

}


