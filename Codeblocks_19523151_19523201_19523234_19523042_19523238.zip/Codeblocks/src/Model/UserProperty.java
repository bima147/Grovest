/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;


/**
 *
 * @author Riko
 */
public class UserProperty {
    private String pemilik, pengelola;
    private int id;
    private String nama, gender, alamat, email;
    
    public UserProperty(int id, String nama, String gender, String alamat, String email) {
	    this.id = id;
	    this.nama = nama;
	    this.gender = gender;
	    this.alamat = alamat;
	    this.email = email;
    }

    public UserProperty(String pemilik, String pengelola) {
        this.pemilik = pemilik;
        this.pengelola = pengelola;
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNama() {
		return nama;
	}

	public void setNama(String nama) {
		this.nama = nama;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAlamat() {
		return alamat;
	}

	public void setAlamat(String alamat) {
		this.alamat = alamat;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

    public String getPemilik() {
        return pemilik;
    }

    public void setPemilik(String pemilik) {
        this.pemilik = pemilik;
    }

    public String getPengelola() {
        return pengelola;
    }

    public void setPengelola(String pengelola) {
        this.pengelola = pengelola;
    }
    
}

