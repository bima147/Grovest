/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Riko
 */
public class DataTanah {
    //Buat array list
    public List<String> lokasi;
    public List<Integer> luasL;
    public List<String> jenisTanah;
    public List<Integer> hargaPerbulan;
    public List<Integer> hargaPertahun;

    public DataTanah() {
        //Deklarasi Array List
        lokasi = new ArrayList<>();
        luasL = new ArrayList<>();
        jenisTanah = new ArrayList<>();
        hargaPerbulan = new ArrayList<>();
        hargaPertahun = new ArrayList<>();
        
    }
    
    public DataTanah(String lokasi, Integer luasL, String jenisTanah, 
        Integer hargaPerbulan, Integer hargaPertahun) {
        this.lokasi.add(lokasi);
        this.luasL.add(luasL);
        this.jenisTanah.add(jenisTanah);
        this.hargaPerbulan.add(hargaPerbulan);
        this.hargaPertahun.add(hargaPertahun);
    }
    
    /* set dengan satu parameter untuk menambahkan arraylist, 2 parameter
       untuk menimpa arraylist dengan value yang baru
    */ 
    
    public String getLokasi(int data) {
        return lokasi.get(data);
    }

    public void setLokasi(String lokasiL) {
        lokasi.add( lokasiL);
    }
    
    public void setLokasi(int data, String lokasiL) {
        lokasi.set(data, lokasiL);
    }

    public Integer getLuasL(int data) {
        return luasL.get(data);
    }

    public void setLuasL(Integer luas) {
        luasL.add( luas);
    }
    
    public void setLuasL(int data, Integer luas) {
        luasL.set(data, luas);
    }

    public String getJenisTanah(int data) {
        return jenisTanah.get(data);
    }

    public void setJenisTanah(String jenis) {
        jenisTanah.add( jenis);
    }
    
    public void setJenisTanah(int data, String jenis) {
        jenisTanah.set(data, jenis);
    }

    public Integer getHargaPerbulan(int data) {
        return hargaPerbulan.get(data);
    }

    public void setHargaPerbulan(Integer hPb) {
        hargaPerbulan.add(hPb);
    }
    
    public void setHargaPerbulan(int data, Integer hPb) {
        hargaPerbulan.set(data, hPb);
    }

    public Integer getHargaPertahun(int data) {
        return hargaPertahun.get(data);
    }

    public void setHargaPertahun(Integer hPt) {
        hargaPertahun.add(hPt);
    }
    
    public void setHargaPertahun(int data, Integer hPt) {
        hargaPertahun.set(data, hPt);
    }
}

