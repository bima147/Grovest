/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Register;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import Model.User;
import java.util.InputMismatchException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;

/**
 * FXML Controller class
 * @Codeblocks
 * @author Bima Prakoso
 */
public class RegisterController implements Initializable {
	
	User user = new User();
	int idUser;
	XStream xstream = new XStream(new StaxDriver());
	
	@FXML
	private TextField tfNama;
	
	@FXML
	private TextField tfNomer;
	
	@FXML
	private TextArea taAlamat;
	
	@FXML
	private TextField tfEmail;
	
	@FXML
	private PasswordField pfPassword;
	
	@FXML
	private ComboBox<String> cmbGender;
	
	@FXML
	private Button ButtonLogin;
	
	ObservableList<String> list = FXCollections.observableArrayList("Laki-Laki", "Perempuan");

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		bukaXML();
		cmbGender.setItems(list);
		
	}

	@FXML
	private void HandleButtonRegister(ActionEvent event) throws IOException {
		Integer nomer;
		try {
			nomer = Integer.parseInt(tfNomer.getText());
			user.setNama(tfNama.getText());
			user.setNomer(nomer.toString());
			user.setGender(cmbGender.getValue());
			user.setAlamat(taAlamat.getText());
			user.setAvatar("E:\\Codeblocks\\src\\Images\\avatar.png");
			if(tfEmail.getText().length() < 4 || pfPassword.getText().length() < 4){
				throw new Exception();
			}
			user.setEmail(tfEmail.getText());
			user.setPassword(pfPassword.getText());
			simpanXML();
			
			tfNama.setText("");
			tfNomer.setText("");
			cmbGender.setValue("Pilih Salah Satu");
			taAlamat.setText("");
			tfEmail.setText("");
			pfPassword.setText("");
			
			Alert alertClose = new Alert(Alert.AlertType.INFORMATION);
			alertClose.setContentText("Akun anda telah berhasil didaftarkan!");
			alertClose.showAndWait();
		} catch (Exception e) {
			Alert alertClose = new Alert(Alert.AlertType.ERROR);
			alertClose.setContentText("Terdapat data yang belum diisi/tidak sesuai \n\n Silahkan periksa kembali!");
			alertClose.showAndWait();
		}
	}

	@FXML
	private void HandleButtonLogin(ActionEvent event) throws IOException {
		if(user.nama.size() == 0) {
				Alert alertClose = new Alert(Alert.AlertType.ERROR);
				alertClose.setTitle("Perhatian");
				alertClose.setHeaderText("Tidak ada akun yang terdaftar");
				alertClose.setContentText("Silahkan daftar terlebih dahulu!");
				alertClose.showAndWait();
				loadWindow("/Register/Register.fxml", "Grovest | Register", ButtonLogin);
		} else {
			loadWindow("/Login/Login.fxml", "Grovest | Login", ButtonLogin);
		}
	}	
	
	public void simpanXML() {
		String xml = xstream.toXML(user);
		FileOutputStream out = null;
		try{
			out = new FileOutputStream("data/Users.xml");
			byte[] bytes = xml.getBytes("UTF-8");
			out.write(bytes);
		} catch(Exception e){
			System.err.println("Attention : " + e.getMessage());
		} finally{
			if(out != null){
				try{
					out.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}   
	}
	
	public void bukaXML() {
		FileInputStream in = null;
		try{
			in = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = in.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			user = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("Buka FIle Terdapat Permasalahan : " + e.getMessage());
		} finally{
			if(in != null){
				try{
					in.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	public void loadWindow(String location, String title, Button button) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
		Scene scene = new Scene(root);
		Stage stage = (Stage) button.getScene().getWindow();
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}
	
}

