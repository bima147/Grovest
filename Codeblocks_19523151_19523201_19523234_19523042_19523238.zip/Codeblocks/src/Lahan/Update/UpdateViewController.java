/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lahan.Update;

import Lahan.LahanViewController;
import Model.DataTanah;
import Model.InfoLahan;
import Model.User;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import de.jensd.fx.glyphs.GlyphsDude;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcons;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Codeblocks
 */
public class UpdateViewController implements Initializable {

	InfoLahan il;
	User us;
	XStream xstream = new XStream(new StaxDriver());

	@FXML
	private TextField datake;
	
        @FXML
	private TextField TFNamaPemilik;
	
        @FXML
	private TextField TFNamaPengelola;
	
        @FXML
	private TextField lokasi;
	
        @FXML
	private TextField luasLahan;
	
        @FXML
	private TextField jenisLahan;
	
        @FXML
	private TextField hargaPerbulan;
	
        @FXML
	private TextField hargaPertahun;
	
        @FXML
	private TextField jenisTanaman;
	
        @FXML
	private Label statusSimpan;
	
        @FXML
	private Button btnNama;
	
        @FXML
	private HBox iconSearch;
        
        @FXML
        private Button buttonHome;
        
        @FXML
        private Button buttonProfile;
        
        @FXML
        private Button buttonKeluar;
        
        @FXML
        private Label lbWelcome;
        
        @FXML
        private Button buttonKembali;
        
        @FXML
        private Button ButtonSimpan;
	@FXML
	private ImageView gambarProfile;
	
	
	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		bukaXML();
		String image = "";
		for(int id = 0;id < us.id.size(); id++) {
			int userId = us.getId(id);
			btnNama.setText(String.valueOf(us.getNama(userId)));
			if(us.getAvatar(userId).equals(image)){
				
			} else {
				image = us.getAvatar(userId);
				File file = new File(image);
				Image ava = new Image(file.toURI().toString());
				gambarProfile.setImage(ava);
			}
		}
		iconSearch.getChildren().addAll(GlyphsDude.createIcon(FontAwesomeIcons.SEARCH, "18px"));
		
		bukaXMLLahan();
		bukaXMLUser();	
		TFNamaPemilik.setDisable(true);
		TFNamaPengelola.setDisable(true);
		lokasi.setDisable(true);
		luasLahan.setDisable(true);
		jenisLahan.setDisable(true);
		jenisTanaman.setDisable(true);
		hargaPerbulan.setDisable(true);
		hargaPertahun.setDisable(true);
	}
	
	@FXML
	private void buttonSimpan(ActionEvent event) {
		//membuat variabel yang diperlukan
		Integer hpBulan, hpTahun,lLahan, data;

		try{
			//Mengubah input string ke dalam double atau integer
			data = Integer.parseInt(datake.getText()) - 1;	
			//Minus 1 untuk menyesuaikan dengan array
			lLahan = Integer.parseInt(luasLahan.getText());
			hpBulan = Integer.parseInt(hargaPerbulan.getText());
			hpTahun = Integer.parseInt(hargaPertahun.getText());

			//mengeset dari input agar diterima variabel
			us.setPemilik(data, TFNamaPemilik.getText());
			us.setPengelola(data, TFNamaPengelola.getText());
			il.setLokasi(data, lokasi.getText());
			il.setLuasL(data, lLahan);
			il.setJenisTanah(data, jenisLahan.getText());
			il.setHargaPerbulan(data, hpBulan);
			il.setHargaPertahun(data, hpTahun);
			il.setJenisTanaman(data, jenisTanaman.getText());

			//Menyimpan file
			String xml = xstream.toXML(il);
			FileOutputStream f = null;
			try{
				f = new FileOutputStream("data/File Lahan.xml");
				byte[] bytes = xml.getBytes("UTF-8");
				f.write(bytes);
			} catch(Exception e){
				System.err.println("Attention : " + e.getMessage());
			} finally{
				if(f != null){
					try{
						f.close();
					} catch(IOException e){
						e.printStackTrace();
					}
				}
			}
			//Menyimpan file
			String xlmUser = xstream.toXML(us);
			FileOutputStream of = null;
			try{
				of = new FileOutputStream("data/Users.xml");
				byte[] bytes = xlmUser.getBytes("UTF-8");
				of.write(bytes);
			} catch(Exception e){
				System.err.println("Attention : " + e.getMessage());
			} finally{
				if(of != null){
					try{
						of.close();
						statusSimpan.setText("Berhasil Disimpan");

						//Mengembalikan ke view infolahan
						loadWindow("/Lahan/LihatLahan.fxml", "Lihat Details - Lihat Lahan", ButtonSimpan);
					} catch(IOException e){
						e.printStackTrace();
					}
				}
			}
		//Menangakap warning
		} catch(NumberFormatException e){
			Alert alertKosong = new Alert(Alert.AlertType.WARNING);
			alertKosong.setTitle("Pemberitahuan");
			alertKosong.setHeaderText("Perbarui data gagal!");
			alertKosong.setContentText("Ada form yang tidak sesuai / belum diisi, Silahkan perikasa kembali!");
			alertKosong.showAndWait();
		}
	}

	//Load XML
	void bukaXMLLahan(){
		FileInputStream coba = null;
		try{
			coba = new FileInputStream("data/File Lahan.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = coba.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			il = (InfoLahan) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("test : " + e.getMessage());
		} finally{
			if(coba != null){
				try{
					coba.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}

	void bukaXMLUser(){
		FileInputStream coba = null;
		try{
			coba = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = coba.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			us = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("test : " + e.getMessage());
		} finally{
			if(coba != null){
				try{
					coba.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	public void loadWindow(String location, String title, Button button) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
                Stage stage = (Stage) button.getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	private void ButtonHandleHome(ActionEvent event) throws IOException {
		loadWindow("/Home/HomeView.fxml", "Home - Grovest", buttonHome);
	}

	@FXML
	private void handelButtonLogout(ActionEvent event) {
		Alert alertClose = new Alert(Alert.AlertType.CONFIRMATION);
		alertClose.setTitle("Konfirmasi untuk keluar");
		alertClose.setHeaderText("Apakah anda yakin akan keluar dari aplikasi?");
		alertClose.setContentText("Tekan OK untuk keluar dari aplikasi");
		alertClose.showAndWait().ifPresent(response -> {
			if(response == ButtonType.OK) {
				System.exit(0);
			}
		});
	}

	@FXML
	private void handleButtonBack(ActionEvent event) throws IOException {
		loadWindow("/Lahan/LahanView.fxml", "List Lahan - Grovest", buttonKembali);
	}
	
	public void bukaXML() {
		FileInputStream user = null;
		try{
			user = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = user.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			us = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("Buka FIle Terdapat Permasalahan : " + e.getMessage());
		} finally{
			if(user != null){
				try{
					user.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	@FXML
	private void handleButtonProfile(ActionEvent event) throws IOException {
		loadWindow("/Profile/ProfileView.fxml","Profil - Grovest", buttonProfile);
	}
	
	@FXML
	private void handleButtonSearch(ActionEvent event) {
		int idUser = 0;
		while(idUser < (us.id.size() - 1)) {
			idUser++;
		}
		int userId = us.getId(idUser);
		int id = Integer.parseInt(datake.getText()) - 1;
		if(us.getPemilik(id).equals(us.getNama(userId))) {
			TFNamaPemilik.setText(us.getPemilik(id));
			TFNamaPengelola.setText(us.getPengelola(id));
			lokasi.setText(il.getLokasi(id));
			luasLahan.setText(String.valueOf(il.getLuasL(id)));
			jenisLahan.setText(il.getJenisTanaman(id));
			jenisTanaman.setText(il.getJenisTanaman(id));
			hargaPerbulan.setText(String.valueOf(il.getHargaPerbulan(id)));
			hargaPertahun.setText(String.valueOf(il.getHargaPertahun(id)));
			TFNamaPemilik.setDisable(false);
			TFNamaPengelola.setDisable(false);
			lokasi.setDisable(false);
			luasLahan.setDisable(false);
			jenisLahan.setDisable(false);
			jenisTanaman.setDisable(false);
			hargaPerbulan.setDisable(false);
			hargaPertahun.setDisable(false);
		} else {
			Alert alertKosong = new Alert(Alert.AlertType.WARNING);
			alertKosong.setTitle("Pemberitahuan");
			alertKosong.setHeaderText("Hapus data GAGAL!");
			alertKosong.setContentText("Anda tidak dapat mengubah data milik pengguna lain!");
			alertKosong.showAndWait();
		}
	}

	private void HandleButtonInfo(ActionEvent event) {
		Alert alertKosong = new Alert(Alert.AlertType.INFORMATION);
		alertKosong.setTitle("Informasi");
		alertKosong.setHeaderText("Silahkan baca petunjuk dengan teliti");
		alertKosong.setContentText("Silahkan isi form No. Lahan dan klik cari lahan \nSetelah itu, silahkan ubah data sesuai yang anda inginkan \nLalu klik Perbarui");
		alertKosong.showAndWait();
	}
	
}










































