/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lahan.Statistika;

import Model.InfoLahan;
import Model.User;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import de.jensd.fx.glyphs.GlyphsDude;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcons;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.Tooltip;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Codeblocks
 */
public class DiagramViewController implements Initializable {

	InfoLahan il = new InfoLahan();
	XYChart.Series<String, Integer> perBulan = new XYChart.Series();
	XYChart.Series<String, Integer> perTahun = new XYChart.Series();
    
	User us;
	XStream xstream = new XStream(new StaxDriver());
	
	@FXML
	private Button btnNama;
        
	@FXML
	private HBox iconSearch;
        
	@FXML
	private Label lbWelcome;
        
	@FXML
	private BarChart bcHarga;
        
        @FXML
        private Button buttonHome;
        
         @FXML
        private Button buttonProfile;
        
        @FXML
        private Button buttonKeluar;
        
        @FXML
        private Button buttonBack;
	@FXML
	private ImageView gambarProfile;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		bukaXML();
		String image = "";
		for(int id = 0;id < us.id.size(); id++) {
			int userId = us.getId(id);
			btnNama.setText(String.valueOf(us.getNama(userId)));
			if(us.getAvatar(userId).equals(image)){
				
			} else {
				image = us.getAvatar(userId);
				File file = new File(image);
				Image ava = new Image(file.toURI().toString());
				gambarProfile.setImage(ava);
			}
		}
		iconSearch.getChildren().addAll(GlyphsDude.createIcon(FontAwesomeIcons.SEARCH, "18px"));
		
		bukaXMLLahan();
		setBarChart();
	}	

	@FXML
	private void ButtonHandleHome(ActionEvent event) throws IOException {
		loadWindow("/Home/HomeView.fxml", "Home - Grovest", buttonHome);
	}

	@FXML
	private void handelButtonLogout(ActionEvent event) {
		Alert alertClose = new Alert(Alert.AlertType.CONFIRMATION);
		alertClose.setTitle("Konfirmasi untuk keluar");
		alertClose.setHeaderText("Apakah anda yakin akan keluar dari aplikasi?");
		alertClose.setContentText("Tekan OK untuk keluar dari aplikasi");
		alertClose.showAndWait().ifPresent(response -> {
			if(response == ButtonType.OK) {
				System.exit(0);
			}
		});
	}

	@FXML
	private void handleButtonBack(ActionEvent event) throws IOException {
		loadWindow("/Lahan/LahanView.fxml", "List Lahan - Grovest", buttonBack);
	}
	
	public void loadWindow(String location, String title, Button button) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
                Stage stage = (Stage) button.getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}
	
	public void bukaXML() {
		FileInputStream user = null;
		try{
			user = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = user.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			us = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("Buka FIle Terdapat Permasalahan : " + e.getMessage());
		} finally{
			if(user != null){
				try{
					user.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	void setBarChart(){
		int noLahan = 1;
		String namaLahan;
		for(int harga : il.hargaPerbulan){
			harga = harga * 12;
			namaLahan = "Lahan " + noLahan;
			System.out.println(namaLahan);
			//Bar harga perbulan
			perBulan.getData().add(new XYChart.Data<>(namaLahan, harga));
			perBulan.setName("Pendapatan Sewa Per-Bulan");

			//Bar harga perTahun
			perTahun.getData().add(new XYChart.Data<>(namaLahan, il.getHargaPertahun(noLahan - 1)));
			perTahun.setName("Pendapatan Sewa Per-Tahun");

			noLahan = noLahan + 1;
		}
		bcHarga.getData().addAll(perBulan, perTahun);

		//eventHandlerPerBulan
		for(final XYChart.Data<String, Integer> data : perBulan.getData()){
			data.getNode().addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
				    //status.setText(String.valueOf(data.getYValue()));
					Tooltip.install(data.getNode(), new Tooltip(data.getYValue().toString()));
				}
			});
		}

		//eventHandlerPerTahun
		for(final XYChart.Data<String, Integer> data : perTahun.getData()){
			data.getNode().addEventHandler(MouseEvent.MOUSE_ENTERED, new EventHandler<MouseEvent>() {
				@Override
				public void handle(MouseEvent event) {
					//status.setText(String.valueOf(data.getYValue()));
					Tooltip.install(data.getNode(), new Tooltip(data.getYValue().toString()));
				}
			});
		
		}
	}

	    void bukaXMLLahan(){
		FileInputStream coba = null;
		try{
		    coba = new FileInputStream("data/File Lahan.xml");
		    int isi;
		    char c;
		    String stringnya = "";

		    while((isi = coba.read()) != -1){
			c = (char) isi;
			stringnya = stringnya + c;
		    }
		    il = (InfoLahan) xstream.fromXML(stringnya);
		} catch(Exception e){
		    System.err.println("test : " + e.getMessage());
		} finally{
		    if(coba != null){
			try{
			    coba.close();
			} catch(IOException e){
			    e.printStackTrace();
			}
		    }
		}
	    }
	    
	@FXML
	private void handleButtonProfile(ActionEvent event) throws IOException {
		loadWindow("/Profile/ProfileView.fxml","Profil - Grovest", buttonProfile);
	}
}






















