/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lahan;

import Model.InfoLahan;
import Model.User;
import Model.UserProperty;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import de.jensd.fx.glyphs.GlyphsDude;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcons;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author Codeblocks
 */
public class LahanViewController implements Initializable {
	
	InfoLahan il = new InfoLahan();
	User us = new User();
	XStream xstream = new XStream(new StaxDriver());
	private int index;

	ObservableList<UserProperty> listUser = FXCollections.observableArrayList();

	@FXML 
	private TableView<UserProperty> tvLahan;
	@FXML 
	private TableColumn<UserProperty, String> tcPemilik;
	@FXML 
	private TableColumn<UserProperty, String> tcPengelola;

	@FXML
	private Button btnNama;
	
	@FXML
	private Label JenisLahan;
	
	@FXML
	private Label NamaPemilik;
	
	@FXML
	private Label NamaPengelola;
	
	@FXML
	private Label Lokasi;
	
	@FXML
	private Label LuasLahan;
	
	@FXML
	private Label HargaBulan;
	
	@FXML
	private Label HargaTahun;
	
	@FXML
	private Label JenisTanaman;
	
	@FXML
	private HBox iconSearch;
        @FXML
        private Label lbWelcome;
        @FXML
        private Button buttonTambah;
        
        @FXML
        private Button buttonHome;
        
        @FXML
        private Button buttonLahan;
        
        @FXML
        private Button buttonKeluar;
        
        @FXML
        private Button buttonUpdate;
        
        @FXML
        private Button buttonGrafik;
        
        @FXML
        private Button buttonProfile;
	@FXML
	private ImageView gambarProfile;
	@FXML
	private TextField tfSearch;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		bukaXMLLahan();
		bukaXMLUser();
		String image = "";
		for(int id = 0;id < us.id.size(); id++) {
			int userId = us.getId(id);
			btnNama.setText(String.valueOf(us.getNama(userId)));
			if(us.getAvatar(userId).equals(image)){
				
			} else {
				image = us.getAvatar(userId);
				File file = new File(image);
				Image ava = new Image(file.toURI().toString());
				gambarProfile.setImage(ava);
			}
		}
		iconSearch.getChildren().addAll(GlyphsDude.createIcon(FontAwesomeIcons.SEARCH, "18px"));
		
		for(int i=0; i<us.pemilik.size(); i++ ){
			listUser.add(new UserProperty(us.getPemilik(i), us.getPengelola(i)));
		}
		
		tcPemilik.setCellValueFactory(new PropertyValueFactory<UserProperty, String>("pemilik"));
		tcPengelola.setCellValueFactory(new PropertyValueFactory<UserProperty, String>("pengelola"));
		tvLahan.setItems(listUser);
	}	
	
	@FXML
	private void menuBuatLahan(ActionEvent event) throws IOException {
		loadWindow("/Lahan/Input/InputView.fxml", "Input Lahan - Grovest", buttonTambah);
	}
	
	@FXML
	private void menuStatistika(ActionEvent event) throws IOException {
		loadWindow("/Lahan/Statistika/DiagramView.fxml", "Diagram Lahan - Grovest", buttonGrafik);
	}
        
	@FXML
	private void mouseKlik(MouseEvent event) {
		index =  tvLahan.getSelectionModel().getSelectedIndex();
		//Mengeset Text Field
		setTeks(index);
	}

	@FXML
	private void ButtonUpdate(ActionEvent event) throws IOException {
		loadWindow("/Lahan/Update/UpdateView.fxml", "Update Lahan - Grovest", buttonUpdate);
	}

	@FXML
	private void buttonDelete(ActionEvent event) throws IOException{
		index =  tvLahan.getSelectionModel().getSelectedIndex();
		int idUser = 0;
		while(idUser < (us.id.size() - 1)) {
			idUser++;
		}
		int userId = us.getId(idUser);
		if(us.getNama(userId).equals(us.getPemilik(index))) {
			// Confirmation delete
			Alert alertClose = new Alert(Alert.AlertType.CONFIRMATION);
			alertClose.setTitle("Konfirmasi Hapus Data");
			alertClose.setHeaderText("Apakah anda yakin akan menghapus data ini?");
			alertClose.setContentText("Lahan milik anda yang dikelola oleh" + us.getPengelola(index) + " akan dihapus" );
			alertClose.showAndWait().ifPresent(response -> {
				if(response == ButtonType.OK) {
					// Menghapus Data
					hapusTeks(index);
					simpanXMLLahan();
					simpanXMLUser();
					Alert alertKosong = new Alert(Alert.AlertType.INFORMATION);
					alertKosong.setTitle("Data Terhapus");
					alertKosong.setHeaderText("Data telah terhapus");
					alertKosong.setContentText("Penghapusan data telah berhasil");
					alertKosong.showAndWait();
				}
			});
		} else {
			Alert alertClose = new Alert(Alert.AlertType.INFORMATION);
			alertClose.setTitle("Pemberitahuan");
			alertClose.setHeaderText("Penghapusan Gagal!");
			alertClose.setContentText("Anda tidak dapat menghapus jika bukan punya anda");
			alertClose.showAndWait();
		}
		
		if(us.pemilik.size() == 0) {
			loadWindow("/Lahan/Input/InputView.fxml","List Lahan - Grovest", buttonLahan);
		}
	}

	void setTeks(int data){
		if(il != null){
			NamaPemilik.setText(us.getPemilik(data));
			NamaPengelola.setText(us.getPengelola(data));
			Lokasi.setText(il.getLokasi(data));
			LuasLahan.setText(String.valueOf(il.getLuasL(data)));
			JenisLahan.setText(il.getJenisTanaman(data));
			HargaBulan.setText(String.valueOf(il.getHargaPerbulan(data)));
			HargaTahun.setText(String.valueOf(il.getHargaPertahun(data)));
			JenisTanaman.setText(il.getJenisTanaman(data));
		} else{
			NamaPemilik.setText("");
			NamaPengelola.setText("");
			Lokasi.setText("");
			LuasLahan.setText("");
			JenisLahan.setText("");
			HargaBulan.setText("");
			HargaTahun.setText("");
			JenisTanaman.setText("");  
		}
	}

	void hapusTeks(int data){
		listUser.remove(data);
		us.pemilik.remove(data);
		us.pengelola.remove(data);
		il.lokasi.remove(data);
		il.luasL.remove(data);
		il.jenisTanah.remove(data);
		il.hargaPerbulan.remove(data);
		il.hargaPertahun.remove(data);
		il.jenisTanaman.remove(data);
	}
	
	public void loadWindow(String location, String title, Button button) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
                Stage stage = (Stage) button.getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}
	
	void bukaXMLLahan(){
		FileInputStream coba = null;
		try{
			coba = new FileInputStream("data/File Lahan.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = coba.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			il = (InfoLahan) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("test : " + e.getMessage());
		} finally{
			if(coba != null){
				try{
					coba.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}

	void bukaXMLUser(){
		FileInputStream coba = null;
		try{
			coba = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = coba.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			us = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("test : " + e.getMessage());
		} finally{
			if(coba != null){
				try{
					coba.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}

	void simpanXMLLahan(){
		String xml = xstream.toXML(il);
		FileOutputStream f = null;
		try{
			f = new FileOutputStream("data/File Lahan.xml");
			byte[] bytes = xml.getBytes("UTF-8");
			f.write(bytes);
		} catch(Exception e){
			System.err.println("Attention : " + e.getMessage());
		} finally{
			if(f != null){
				try{
					f.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}

	void simpanXMLUser(){
		String xml = xstream.toXML(us);
		FileOutputStream f = null;
		try{
			f = new FileOutputStream("data/Users.xml");
			byte[] bytes = xml.getBytes("UTF-8");
			f.write(bytes);
		} catch(Exception e){
			System.err.println("Attention : " + e.getMessage());
		} finally{
			if(f != null){
				try{
					f.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}

	@FXML
	private void ButtonHandleHome(ActionEvent event) throws IOException {
		loadWindow("/Home/HomeView.fxml", "Home - Grovest", buttonHome);
	}
	
	@FXML
	private void handleButtonProfile(ActionEvent event) throws IOException {
		loadWindow("/Profile/ProfileView.fxml","Profil - Grovest", buttonProfile);
	}

	@FXML
	private void handelButtonLogout(ActionEvent event) {
		Alert alertClose = new Alert(Alert.AlertType.CONFIRMATION);
		alertClose.setTitle("Konfirmasi untuk keluar");
		alertClose.setHeaderText("Apakah anda yakin akan keluar dari aplikasi?");
		alertClose.setContentText("Tekan OK untuk keluar dari aplikasi");
		alertClose.showAndWait().ifPresent(response -> {
			if(response == ButtonType.OK) {
				System.exit(0);
			}
		});
	}
	
}






















































