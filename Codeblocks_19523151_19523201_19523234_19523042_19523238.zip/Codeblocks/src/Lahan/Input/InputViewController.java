/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Lahan.Input;

import Model.InfoLahan;
import Model.User;
import Model.UserProperty;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import de.jensd.fx.glyphs.GlyphsDude;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcons;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author asus
 */
public class InputViewController implements Initializable {
	
	InfoLahan il = new InfoLahan();
	User us = new User();
	UserProperty up;
	XStream xstream = new XStream(new StaxDriver());
	
	@FXML
	private Button btnNama;
	
	@FXML
	private HBox iconSearch;
	
	@FXML
	private Label lbWelcome;
	
	@FXML
	private TextField TFNamaPemilik;
	
	@FXML
	private TextField TFNamaPengelola;
	
	@FXML
	private TextField lokasi;
	
	@FXML
	private TextField luasLahan;
	
	@FXML
	private TextField jenisLahan;
	
	@FXML
	private TextField jenisTanaman;
	
	@FXML
	private TextField hargaPerbulan;
	
	@FXML
	private TextField hargaPertahun;
	
	@FXML
	private Label statusSimpan;
        
        @FXML
        private Button buttonHome;
        
        @FXML
        private Button buttonKeluar;
        
        @FXML
        private Button buttonBack;
        
        @FXML
        private Button buttonProfile;
	@FXML
	private ImageView gambarProfile;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		bukaXMLUser();
                bukaXMLLahan();
		String image = "";
		for(int id = 0;id < us.id.size(); id++) {
			int userId = us.getId(id);
			btnNama.setText(String.valueOf(us.getNama(userId)));
			TFNamaPemilik.setText(us.getNama(userId));
			TFNamaPemilik.setDisable(true);
			if(us.getAvatar(userId).equals(image)){
				
			} else {
				image = us.getAvatar(userId);
				File file = new File(image);
				Image ava = new Image(file.toURI().toString());
				gambarProfile.setImage(ava);
			}
		}
		iconSearch.getChildren().addAll(GlyphsDude.createIcon(FontAwesomeIcons.SEARCH, "18px"));
		
	}	

	@FXML
	private void ButtonHandleHome(ActionEvent event) throws IOException {
		loadWindow("/Home/HomeView.fxml", "Home - Grovest", buttonHome);
	}

	@FXML
	private void handelButtonLogout(ActionEvent event) {
		Alert alertClose = new Alert(Alert.AlertType.CONFIRMATION);
		alertClose.setTitle("Konfirmasi untuk keluar");
		alertClose.setHeaderText("Apakah anda yakin akan keluar dari aplikasi?");
		alertClose.setContentText("Tekan OK untuk keluar dari aplikasi");
		alertClose.showAndWait().ifPresent(response -> {
			if(response == ButtonType.OK) {
				System.exit(0);
			}
		});
	}

	@FXML
	private void handleButtonBack(ActionEvent event) throws IOException {
		if(us.pemilik.size() == 0) {
			Alert alertClose = new Alert(Alert.AlertType.WARNING);
			alertClose.setTitle("Pemberitahuan");
			alertClose.setHeaderText("Lihat lahan gagal diakses!");
			alertClose.setContentText("Mohon masukkan terlebih dahulu data lahan!");
			alertClose.showAndWait();
		} else {
			loadWindow("/Lahan/LahanView.fxml", "List Lahan - Grovest", buttonBack);
		}
	}

	@FXML
	private void handleButtonUlang(ActionEvent event) {
		TFNamaPengelola.setText("");
		lokasi.setText("");
		luasLahan.setText("");
		jenisLahan.setText("");
		jenisTanaman.setText("");
		hargaPerbulan.setText("");
		hargaPertahun.setText("");
	} 
	
	private void buttonSelanjutnya(ActionEvent event) {
		//membuat variabel yang diperlukan
		Integer hpBulan, hpTahun,lLahan;

		try{
			//Mengubah input string ke dalam double atau integer
			lLahan = Integer.parseInt(luasLahan.getText());
			hpBulan = Integer.parseInt(hargaPerbulan.getText());
			hpTahun = Integer.parseInt(hargaPertahun.getText());

			//mengeset dari input agar diterima variabel
			us.setPemilik(TFNamaPemilik.getText());
			us.setPengelola(TFNamaPengelola.getText());
			il.setLokasi(lokasi.getText());
			il.setLuasL(lLahan);
			il.setJenisTanah(jenisLahan.getText());
			il.setHargaPerbulan(hpBulan);
			il.setHargaPertahun(hpTahun);
			il.setJenisTanaman(jenisTanaman.getText());

			//Melakukan reset untuk memasukan data selanjutnya
			TFNamaPengelola.setText("");
			lokasi.setText("");
			luasLahan.setText("");
			jenisLahan.setText("");
			hargaPerbulan.setText("");
			hargaPertahun.setText("");
			statusSimpan.setText("");
			jenisTanaman.setText("");
		} catch(NumberFormatException e){
			//Membuat error box
			Alert alertKosong = new Alert(Alert.AlertType.WARNING);
			alertKosong.setTitle("Pemberitahuan");
			alertKosong.setHeaderText("Pemasukan data gagal!");
			alertKosong.setContentText("Ada form yang tidak sesuai / belum diisi, Silahkan perikasa kembali!");
			alertKosong.showAndWait();
		}
	}

	@FXML
	private void buttonSimpan(ActionEvent event) {
                //Mengubah input string ke dalam double atau integer
                Integer hpBulan, hpTahun,lLahan;
		lLahan = Integer.parseInt(luasLahan.getText());
		hpBulan = Integer.parseInt(hargaPerbulan.getText());
		hpTahun = Integer.parseInt(hargaPertahun.getText());

		//mengeset dari input agar diterima variabel
		us.setPemilik(TFNamaPemilik.getText());
		us.setPengelola(TFNamaPengelola.getText());
		il.setLokasi(lokasi.getText());
		il.setLuasL(lLahan);
		il.setJenisTanah(jenisLahan.getText());
		il.setHargaPerbulan(hpBulan);
		il.setHargaPertahun(hpTahun);
		il.setJenisTanaman(jenisTanaman.getText());

		String xml = xstream.toXML(il);
		FileOutputStream f = null;
		try{
			f = new FileOutputStream("data/File Lahan.xml");
			byte[] bytes = xml.getBytes("UTF-8");
			f.write(bytes);
		} catch(Exception e){
			System.err.println("Attention : " + e.getMessage());
		} finally{
			if(f != null){
				try{
					f.close();
					statusSimpan.setText("Berhasil Disimpan");
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
		
		String xml1 = xstream.toXML(us);
		FileOutputStream g = null;
		try{
			g = new FileOutputStream("data/Users.xml");
			byte[] bytes = xml1.getBytes("UTF-8");
			g.write(bytes);
		} catch(Exception e){
			System.err.println("Attention : " + e.getMessage());
		} finally{
			if(g != null){
				try{
					g.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
		
		TFNamaPengelola.setText("");
		lokasi.setText("");
		luasLahan.setText("");
		jenisLahan.setText("");
		hargaPerbulan.setText("");
		hargaPertahun.setText("");
		statusSimpan.setText("");
		jenisTanaman.setText("");
		
		statusSimpan.setText("Data berhasil disimpan!");
	}
	
	public void loadWindow(String location, String title, Button button) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
                Stage stage = (Stage) button.getScene().getWindow();
		Scene scene = new Scene(root);
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}
	
	public void bukaXMLUser() {
		FileInputStream user = null;
		try{
			user = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = user.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			us = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("Buka FIle Terdapat Permasalahan : " + e.getMessage());
		} finally{
			if(user != null){
				try{
					user.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	void bukaXMLLahan(){
		FileInputStream coba = null;
		try{
			coba = new FileInputStream("data/File Lahan.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = coba.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			il = (InfoLahan) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("test : " + e.getMessage());
		} finally{
			if(coba != null){
				try{
					coba.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	@FXML
	private void handleButtonProfile(ActionEvent event) throws IOException {
		loadWindow("/Profile/ProfileView.fxml","Profil - Grovest", buttonProfile);
	}
	
}


























