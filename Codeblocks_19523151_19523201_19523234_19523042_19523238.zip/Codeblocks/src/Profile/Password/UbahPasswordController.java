/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Profile.Password;

import Model.User;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author asus
 */
public class UbahPasswordController implements Initializable {

	User user = new User();
	XStream xstream = new XStream(new StaxDriver());
	@FXML
	private ImageView gambarProfile;
	@FXML
	private Button buttonHome;
	@FXML
	private Button buttonLahan;
	@FXML
	private Button buttonKeluar;
	@FXML
	private Button btnNama;
	@FXML
	private HBox iconSearch;
	@FXML
	private Label lbWelcome;
	@FXML
	private Label statusSimpan;
	@FXML
	private Button buttonBack;
	@FXML
	private PasswordField pfPasswordBaru;
	@FXML
	private PasswordField pfUlangiPassword;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		bukaXML();
		String image = "";
		for(int id = 0;id < user.id.size(); id++) {
			int userId = user.getId(id);
			btnNama.setText(String.valueOf(user.getNama(userId)));
			
			if(user.getAvatar(userId).equals(image)){
				
			} else {
				image = user.getAvatar(userId);
				File file = new File(image);
				Image ava = new Image(file.toURI().toString());
				gambarProfile.setImage(ava);
			}
		}
	}	

	@FXML
	private void ButtonHandleHome(ActionEvent event) throws IOException {
		loadWindow("/Home/HomeView.fxml", "Home - Grovest", buttonHome);
	}

	@FXML
	private void handleButtonLahan(ActionEvent event) throws IOException {
		if(user.pemilik.size() == 0) {
			loadWindow("/Lahan/Input/InputView.fxml","List Lahan - Grovest", buttonLahan);
		} else {
			loadWindow("/Lahan/LahanView.fxml","List Lahan - Grovest", buttonLahan);
		}
	}

	@FXML
	private void handelButtonLogout(ActionEvent event) {
		Alert alertClose = new Alert(Alert.AlertType.CONFIRMATION);
		alertClose.setTitle("Konfirmasi untuk keluar");
		alertClose.setHeaderText("Apakah anda yakin akan keluar dari aplikasi?");
		alertClose.setContentText("Tekan OK untuk keluar dari aplikasi");
		alertClose.showAndWait().ifPresent(response -> {
			if(response == ButtonType.OK) {
				System.exit(0);
			}
		});
	}

	@FXML
	private void buttonSimpan(ActionEvent event) {
		if(pfPasswordBaru.getText().equals(pfUlangiPassword.getText())) {
			int id = 0;
			int userId = 0;
			while(id < user.id.size()) {
				id++;
			}
			int idUser = id - 1;
			userId = user.getId(idUser);
			user.password.remove(userId);
			user.setPassword(userId, pfPasswordBaru.getText());
			simpanXML();
			pfPasswordBaru.setText("");
			pfUlangiPassword.setText("");
		} else {
			Alert alert = new Alert(Alert.AlertType.WARNING);
			alert.setTitle("Perhatian!");
			alert.setHeaderText("Gagal meperbarui password");
			alert.setContentText("Password yang anda masukkan tidak sama. Silahkan periksa kembali");
			alert.showAndWait();
		}
	}

	@FXML
	private void handleButtonBack(ActionEvent event) throws IOException {
		loadWindow("/Profile/ProfileView.fxml","Profil - Grovest", buttonBack);
	}
	
	public void bukaXML() {
		FileInputStream in = null;
		try{
			in = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = in.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			user = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("Buka FIle Terdapat Permasalahan : " + e.getMessage());
		} finally{
			if(in != null){
				try{
					in.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	public void simpanXML() {
		String xml = xstream.toXML(user);
		FileOutputStream out = null;
		try{
			out = new FileOutputStream("data/Users.xml");
			byte[] bytes = xml.getBytes("UTF-8");
			out.write(bytes);
		} catch(Exception e){
			System.err.println("Attention : " + e.getMessage());
		} finally{
			if(out != null){
				try{
					out.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}   
	}
	
	public void loadWindow(String location, String title, Button button) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
		Scene scene = new Scene(root);
		Stage stage = (Stage) button.getScene().getWindow();
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}
}


















