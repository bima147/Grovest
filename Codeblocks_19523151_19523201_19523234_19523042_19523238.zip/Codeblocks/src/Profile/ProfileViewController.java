/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Profile;

import Model.User;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author asus
 */
public class ProfileViewController implements Initializable {

	User user = new User();
	XStream xstream = new XStream(new StaxDriver());
	@FXML
	private ImageView gambarProfile;
	@FXML
	private Button ButtonHome;
	@FXML
	private Button ButtonLahan;
	@FXML
	private Button btnNama;
	@FXML
	private HBox iconSearch;
	@FXML
	private Label statusSimpan;
	@FXML
	private ImageView gambarProfile1;
	@FXML
	private Button buttonImage;
	@FXML
	private Label lbNama;
	@FXML
	private Label lbGender;
	@FXML
	private Label lbAlamat;
	@FXML
	private Label lbNomer;
	@FXML
	private Label lbEmail;
	@FXML
	private Button buttonPassword;
	@FXML
	private HBox hbLine1;
	@FXML
	private HBox hbLine2;
	@FXML
	private HBox hbLine3;
	@FXML
	private HBox hbLine4;
	@FXML
	private HBox hbLine5;
	@FXML
	private VBox line;
	

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		bukaXML();
		String image = "";
		for(int id = 0;id < user.id.size(); id++) {
			int userId = user.getId(id);
			btnNama.setText(String.valueOf(user.getNama(userId)));
			lbNama.setText(user.getNama(userId));
			lbNomer.setText(user.getNomer(userId));
			lbGender.setText(user.getGender(userId));
			lbAlamat.setText(user.getAlamat(userId));
			lbEmail.setText(user.getEmail(userId));
			
			if(user.getAvatar(userId).equals(image)){
				
			} else {
				image = user.getAvatar(userId);
				File file = new File(image);
				Image ava = new Image(file.toURI().toString());
				gambarProfile.setImage(ava);
				gambarProfile1.setImage(ava);
			}
		}
	}	

	@FXML
	private void handleButtonHome(ActionEvent event) throws IOException {
		loadWindow("/Home/HomeView.fxml", "Home - Grovest", ButtonHome);
	}

	@FXML
	private void handelButtonLogout(ActionEvent event) {
		Alert alertClose = new Alert(Alert.AlertType.CONFIRMATION);
		alertClose.setTitle("Konfirmasi untuk keluar");
		alertClose.setHeaderText("Apakah anda yakin akan keluar dari aplikasi?");
		alertClose.setContentText("Tekan OK untuk keluar dari aplikasi");
		alertClose.showAndWait().ifPresent(response -> {
			if(response == ButtonType.OK) {
				System.exit(0);
			}
		});
	}
	
	public void loadWindow(String location, String title, Button button) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
		Scene scene = new Scene(root);
		Stage stage = (Stage) button.getScene().getWindow();
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}

	@FXML
	private void handleButonLahan(ActionEvent event) throws IOException {
		if(user.pemilik.size() == 0) {
			loadWindow("/Lahan/Input/InputView.fxml","List Lahan - Grovest", ButtonLahan);
		} else {
			loadWindow("/Lahan/LahanView.fxml","List Lahan - Grovest", ButtonLahan);
		}
	}
	
	public void bukaXML() {
		FileInputStream in = null;
		try{
			in = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = in.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			user = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("Buka FIle Terdapat Permasalahan : " + e.getMessage());
		} finally{
			if(in != null){
				try{
					in.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}

	@FXML
	private void handleButtonImage(ActionEvent event) {
		bukaXML();
		String foto = "";
		int userId = 0;
		try {
			FileChooser fc = new FileChooser();
			fc.setInitialDirectory(new File (System.getProperty("user.dir")));
			fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("File Gambar", "*.jpg", "*.png", "*.jpeg"));
			File image = fc.showOpenDialog(null);
			if (image == null){
				Alert alert = new Alert(Alert.AlertType.WARNING);
				alert.setTitle("Perhatian");
				alert.setHeaderText("Gambar tidak dapat ditemukan.");
				alert.setContentText("File tidak sudah dihapus atau file belum dibuat.");
				alert.showAndWait();
			} else{
				int id = 0;
				while(id < user.id.size()) {
					userId = user.getId(id);
					String avatar = user.getAvatar(userId);
					File file = new File(avatar);
					Image ava = new Image(file.toURI().toString());
					gambarProfile.setImage(ava);
					id++;
				}
				int idUser = id - 1;
				userId = user.getId(idUser);
				user.avatar.remove(userId);
				foto = image.getAbsolutePath();
				user.setAvatar(userId, foto);
				user.getAvatar(user.getId(userId));
				simpanXML();
				loadWindow("/Profile/ProfileView.fxml","Profil - Grovest", buttonImage);
			}
		} catch(Exception e) {
			Alert alert = new Alert(Alert.AlertType.WARNING);
			alert.setTitle("ERROR");
			alert.setHeaderText("Gambar gagal diperbarui");
			alert.setContentText("Terjadi kesalahan sistem saat mengubah foto profil");
			alert.showAndWait();
		}
	}
	
	public void simpanXML() {
		String xml = xstream.toXML(user);
		FileOutputStream out = null;
		try{
			out = new FileOutputStream("data/Users.xml");
			byte[] bytes = xml.getBytes("UTF-8");
			out.write(bytes);
		} catch(Exception e){
			System.err.println("Attention : " + e.getMessage());
		} finally{
			if(out != null){
				try{
					out.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}   
	}

	@FXML
	private void handleButtonPassword(ActionEvent event) throws IOException {
		loadWindow("/Profile/Password/UbahPassword.fxml","Ubah Password - Grovest", buttonPassword);
	}
	
}












