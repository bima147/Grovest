/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Landing;

import Model.User;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author asus
 */
public class LandingViewController implements Initializable {

	User user = new User();
	XStream xstream = new XStream(new StaxDriver());

	@FXML
	private Button ButtonLogin;
	
	@FXML
	private Button ButtonRegister;	

	@FXML
	private void HandleButtonLogin(ActionEvent event) throws IOException {
		if(user.nama.size() == 0) {
				Alert alertClose = new Alert(Alert.AlertType.WARNING);
				alertClose.setTitle("Perhatian");
				alertClose.setHeaderText("Tidak ada akun yang terdaftar");
				alertClose.setContentText("Silahkan daftar terlebih dahulu!");
				alertClose.showAndWait();
				loadWindow("/Register/Register.fxml", "Grovest | Register", ButtonRegister);
		}
		loadWindow("/Login/Login.fxml", "Grovest | Login", ButtonLogin);
	}

	@FXML
	private void HandleButtonRegister(ActionEvent event) throws IOException {
		loadWindow("/Register/Register.fxml", "Grovest | Register", ButtonRegister);
	}
	
	public void loadWindow(String location, String title, Button button) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
		Scene scene = new Scene(root);
		Stage stage = (Stage) button.getScene().getWindow();
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		bukaXML();
	}
	
	public void bukaXML() {
		FileInputStream in = null;
		try{
			in = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = in.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			user = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("Buka FIle Terdapat Permasalahan : " + e.getMessage());
		} finally{
			if(in != null){
				try{
					in.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
}


















