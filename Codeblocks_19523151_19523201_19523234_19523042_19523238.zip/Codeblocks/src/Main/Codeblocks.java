/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Model.User;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import java.io.FileInputStream;
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 *
 * @author Codeblocks
 */
public class Codeblocks extends Application {
	
	User user = new User();
	XStream xstream = new XStream(new StaxDriver());
		
	@Override
	public void start(Stage stage) throws Exception {
		loadWindow("/Lahan/LahanView.fxml", "Landing Page - Grovest");
	}
	
	@FXML
	public void bukaXML() {
		FileInputStream in = null;
		try{
			in = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = in.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			user = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("Buka FIle Terdapat Permasalahan : " + e.getMessage());
		} finally{
			if(in != null){
				try{
					in.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	public void loadWindow(String location, String title) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
		Scene scene = new Scene(root);
		Stage stage = new Stage(StageStyle.DECORATED);
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {
		launch(args);
	}
	
}




































