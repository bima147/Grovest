/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Login;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.StaxDriver;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import Model.User;
import java.io.FileOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;

/**
 * FXML Controller class
 * @Codeblocks
 * @author Bima Prakoso
 */
public class LoginController implements Initializable {
	
	User user = new User();
	XStream xstream = new XStream(new StaxDriver());
	int id;
	
	@FXML
	private TextField tfEmail;
	@FXML
	private PasswordField pfPassword;
	@FXML
	private Button ButtonLogin;
	@FXML
	private Button ButtonDaftar;

	/**
	 * Initializes the controller class.
	 */
	@Override
	public void initialize(URL url, ResourceBundle rb) {
		bukaXML();
	}
	
	public void bukaXML() {
		FileInputStream in = null;
		try{
			in = new FileInputStream("data/Users.xml");
			int isi;
			char c;
			String stringnya = "";

			while((isi = in.read()) != -1){
				c = (char) isi;
				stringnya = stringnya + c;
			}
			user = (User) xstream.fromXML(stringnya);
		} catch(Exception e){
			System.err.println("Buka FIle Terdapat Permasalahan : " + e.getMessage());
		} finally{
			if(in != null){
				try{
					in.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}
	}
	
	public void simpanXML() {
		String xml = xstream.toXML(user);
		FileOutputStream out = null;
		try{
			out = new FileOutputStream("data/Users.xml");
			byte[] bytes = xml.getBytes("UTF-8");
			out.write(bytes);
		} catch(Exception e){
			System.err.println("Attention : " + e.getMessage());
		} finally{
			if(out != null){
				try{
					out.close();
				} catch(IOException e){
					e.printStackTrace();
				}
			}
		}   
	}

	@FXML
	private void handleButtonLogin(ActionEvent event) throws IOException {
		for(id = 0; id <= user.nama.size() - 1; id++) {
			user.setId(id);
			simpanXML();
			if(tfEmail.getText().equals(user.getEmail(id)) && pfPassword.getText().equals(user.getPassword(id))){
				id =  user.nama.size() + 1;
				loadWindow("/Home/HomeView.fxml", "Home - Grovest", ButtonLogin);
			} else if(tfEmail.getText() != user.getEmail(id) && pfPassword.getText().equals(user.getPassword(id))) {
				Alert alertClose = new Alert(Alert.AlertType.ERROR);
				alertClose.setTitle("Login Gagal");
				alertClose.setHeaderText("Akun yang Anda Masukkan Tidak Tersedia");
				alertClose.setContentText("Silahkan daftar terlebih dahulu");
				alertClose.showAndWait();
			} else if(tfEmail.getText().equals(user.getEmail(id)) && pfPassword.getText() != user.getPassword(id)) {
				Alert alertClose = new Alert(Alert.AlertType.ERROR);
				alertClose.setTitle("Login Gagal");
				alertClose.setHeaderText("Password yang Anda Masukkan Salah!");
				alertClose.setContentText("Silahkan periksa kembali password yang anda masukkan");
				alertClose.showAndWait();
			} 
			
			if(id == user.nama.size()) {
				Alert alertClose = new Alert(Alert.AlertType.ERROR);
				alertClose.setTitle("ERROR");
				alertClose.setHeaderText("Login GAGAL!");
				alertClose.setContentText("Data yang anda masukkan tidak ada!");
				alertClose.showAndWait();
			}	
			user.id.remove(id);
		}
	}
	
	@FXML
	private void handleButtonRegister(ActionEvent event) throws IOException {
		loadWindow("/Register/Register.fxml", "Grovest | Register", ButtonDaftar);
	}
	
	public void loadWindow(String location, String title, Button button) throws IOException {
		Parent root = FXMLLoader.load(getClass().getResource(location));
		Scene scene = new Scene(root);
		Stage stage = (Stage) button.getScene().getWindow();
		stage.setTitle(title);
		stage.setScene(scene);
		stage.show();
	}
	
	void hapusTeks(int data){
		user.id.remove(data);
	}
}






























































































































